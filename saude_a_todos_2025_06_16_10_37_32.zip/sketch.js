let medicamentos = []; // Array para armazenar nossos objetos de medicamento
let postoX, postoY;   // Posição do posto de saúde
let pessoas = [];     // Array para armazenar as pessoas em movimento

function setup() {
  createCanvas(800, 500); // Cria uma tela de 800 pixels de largura por 500 de altura

  // Define a posição do posto de saúde no centro da tela
  postoX = width / 2;
  postoY = height / 2;

  // Criando alguns medicamentos
  medicamentos.push(new Medicamento("Analgésico", 15));
  medicamentos.push(new Medicamento("Antibiótico", 10));
  medicamentos.push(new Medicamento("Curativo", 20));
  medicamentos.push(new Medicamento("Xarope", 8));
  medicamentos.push(new Medicamento("Soro", 12));
  medicamentos.push(new Medicamento("Anti-inflamatório", 7));
  medicamentos.push(new Medicamento("Vitamina C", 25));

  // Geração inicial de pessoas focada no movimento rural -> urbana
  for (let i = 0; i < 7; i++) {
    let startX = random(0, width / 2); // Sempre começa na zona rural
    let startY = random(0, height);

    let targetX, targetY;
    if (random() < 0.7) { // 70% de chance de ir para a zona urbana (qualquer lugar)
      targetX = random(width / 2, width);
      targetY = random(0, height);
    } else { // 30% de chance de ir para o posto de saúde
      targetX = postoX;
      targetY = postoY;
    }
    pessoas.push(new Pessoa(startX, startY, targetX, targetY));
  }
}

function draw() {
  background(220); // Fundo geral cinza claro

  // Desenha a zona rural e urbana
  drawRuralZone();
  drawUrbanZone();

  // Desenha o posto de saúde
  drawHealthPost();

  // Desenha o painel de estoque de medicamentos com a tabela
  drawMedicinesTablePanel();

  // Atualiza e desenha as pessoas
  for (let i = pessoas.length - 1; i >= 0; i--) {
    let pessoa = pessoas[i];
    pessoa.move();
    pessoa.display();

    // Remove a pessoa se ela atingir o destino e gera uma nova pessoa rural->urbana
    let d = dist(pessoa.x, pessoa.y, pessoa.targetX, pessoa.targetY);
    if (d < 10) { // Se a pessoa chegou perto do destino
      pessoas.splice(i, 1); // Remove a pessoa do array

      // Gera uma NOVA pessoa, sempre começando na zona rural
      let newStartX = random(0, width / 2);
      let newStartY = random(0, height);

      let newTargetX, newTargetY;
      if (random() < 0.7) { // 70% de chance de ir para a zona urbana
        newTargetX = random(width / 2, width);
        newTargetY = random(0, height);
      } else { // 30% de chance de ir para o posto de saúde
        newTargetX = postoX;
        newTargetY = postoY;
      }
      pessoas.push(new Pessoa(newStartX, newStartY, newTargetX, newTargetY));
    }
  }

  // --- Nova função para desenhar a frase de conscientização ---
  drawConsciousnessPhrase();
}

// --- Funções de Desenho ---

function drawRuralZone() {
  fill(120, 180, 80);
  rect(0, 0, width / 2, height);
  fill(100, 70, 40);
  rect(width * 0.1, height * 0.7, 10, 50);
  fill(80, 150, 60);
  ellipse(width * 0.1 + 5, height * 0.65, 40, 40);
  fill(100, 70, 40);
  rect(width * 0.25, height * 0.6, 10, 60);
  fill(80, 150, 60);
  ellipse(width * 0.25 + 5, height * 0.55, 50, 50);
  fill(200, 200, 150);
  rect(width * 0.15, height * 0.75, 60, 40);
  fill(150, 100, 50);
  triangle(width * 0.15, height * 0.75, width * 0.15 + 30, height * 0.70, width * 0.15 + 60, height * 0.75);
}

function drawUrbanZone() {
  fill(180, 190, 200);
  rect(width / 2, 0, width / 2, height);
  fill(100);
  rect(width * 0.55, height * 0.4, 70, 200);
  rect(width * 0.68, height * 0.2, 60, 300);
  rect(width * 0.80, height * 0.5, 80, 150);
  fill(150, 200, 255);
  rect(width * 0.56, height * 0.45, 10, 20);
  rect(width * 0.56, height * 0.55, 10, 20);
  rect(width * 0.56, height * 0.65, 10, 20);
  rect(width * 0.69, height * 0.25, 10, 20);
  rect(width * 0.69, height * 0.35, 10, 20);
  rect(width * 0.69, height * 0.45, 10, 20);
  rect(width * 0.81, height * 0.55, 15, 25);
  rect(width * 0.81, height * 0.65, 15, 25);
  fill(80);
  rect(width / 2, height * 0.85, width / 2, height * 0.15);
  stroke(50);
  strokeWeight(2);
  line(width / 2, 0, width / 2, height);
  noStroke();
}

function drawHealthPost() {
  fill(255);
  ellipse(postoX, postoY, 80, 80);
  fill(200, 0, 0);
  rect(postoX - 25, postoY - 5, 50, 10);
  rect(postoX - 5, postoY - 25, 10, 50);
  fill(0);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("POSTO DE SAÚDE", postoX, postoY + 50);
}

function drawMedicinesTablePanel() {
  let panelX = 580;
  let panelY = 20;
  let panelWidth = 200;
  let panelHeight = 250;
  let headerHeight = 30;
  let rowHeight = 25;

  fill(240, 240, 240);
  rect(panelX, panelY, panelWidth, panelHeight, 10);
  fill(50);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Estoque de medicamentos", panelX + 10, panelY + 10);

  fill(200);
  rect(panelX, panelY + headerHeight, panelWidth, rowHeight);
  fill(50);
  textSize(12);
  textAlign(CENTER, CENTER);
  text("Nome", panelX + panelWidth * 0.3, panelY + headerHeight + rowHeight / 2);
  text("Qtd", panelX + panelWidth * 0.75, panelY + headerHeight + rowHeight / 2);

  for (let i = 0; i < medicamentos.length; i++) {
    let med = medicamentos[i];
    let currentY = panelY + headerHeight + (i + 1) * rowHeight;

    if (i % 2 === 0) {
      fill(255);
    } else {
      fill(230);
    }
    rect(panelX, currentY, panelWidth, rowHeight);

    fill(50);
    textAlign(LEFT, CENTER);
    text(med.nome, panelX + 10, currentY + rowHeight / 2);
    textAlign(CENTER, CENTER);
    text(med.quantidade, panelX + panelWidth * 0.75, currentY + rowHeight / 2);

    med.x = panelX;
    med.y = currentY;
    med.w = panelWidth;
    med.h = rowHeight;
  }
}

// --- NOVA FUNÇÃO: Desenha a frase de conscientização ---
function drawConsciousnessPhrase() {
  fill(50, 50, 150); // Cor azul escuro para o texto
  textSize(24);     // Tamanho da fonte maior
  textAlign(CENTER, TOP); // Alinha o texto ao centro horizontal e ao topo vertical
  text("A saúde da nossa casa depende da saúde do nosso planeta", width / 2, 10);
  // width / 2: centraliza horizontalmente
  // 10: posiciona 10 pixels abaixo do topo da tela
}

// --- Classes (mantidas da versão anterior) ---

class Medicamento {
  constructor(nome, quantidade) {
    this.nome = nome;
    this.quantidade = quantidade;
    this.x = 0;
    this.y = 0;
    this.w = 0;
    this.h = 0;
  }
  use() {
    if (this.quantidade > 0) {
      this.quantidade--;
      return true;
    }
    return false;
  }
  restock(amount) {
    this.quantidade += amount;
  }
}

class Pessoa {
  constructor(startX, startY, targetX, targetY) {
    this.x = startX;
    this.y = startY;
    this.targetX = targetX;
    this.targetY = targetY;
    this.speed = random(0.8, 1.8);
    this.size = 12;
    this.color = color(50, 150, 255); // Azul para pessoas do campo
  }

  display() {
    fill(this.color);
    ellipse(this.x, this.y, this.size, this.size);
    fill(0);
    ellipse(this.x - this.size * 0.15, this.y - this.size * 0.15, this.size * 0.15);
    ellipse(this.x + this.size * 0.15, this.y - this.size * 0.15, this.size * 0.15);
    noStroke();
  }

  move() {
    let angle = atan2(this.targetY - this.y, this.targetX - this.x);
    this.x += cos(angle) * this.speed;
    this.y += sin(angle) * this.speed;
  }
}

// --- Interatividade básica para usar medicamentos ---
function mousePressed() {
  for (let med of medicamentos) {
    if (mouseX > med.x && mouseX < med.x + med.w && mouseY > med.y && mouseY < med.y + med.h) {
      if (med.use()) {
        console.log(med.nome + " usado! Restam: " + med.quantidade);
        redraw();
      } else {
        console.log("Sem " + med.nome + " em estoque!");
      }
      break;
    }
  }
}